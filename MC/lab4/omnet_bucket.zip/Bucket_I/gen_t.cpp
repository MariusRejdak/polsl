#include <omnetpp.h>

class TokenGenerator : public cSimpleModule
{
  private:
    cMessage *sendMessageEvent;

  public:
     TokenGenerator();
     virtual ~TokenGenerator();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

Define_Module( TokenGenerator );

TokenGenerator::TokenGenerator()
{
	sendMessageEvent = NULL;
}

TokenGenerator::~TokenGenerator()
{
	cancelAndDelete(sendMessageEvent);
}

void TokenGenerator::initialize()
{
	sendMessageEvent = new cMessage("nextToken");
	scheduleAt(0.0, sendMessageEvent);
}

void TokenGenerator::handleMessage(cMessage *msg)
{
	ASSERT(msg==sendMessageEvent);

	cMessage *m = new cMessage("token");
	send(m, "out");

	scheduleAt(simTime()+par("sendIaTime"), sendMessageEvent);
}


