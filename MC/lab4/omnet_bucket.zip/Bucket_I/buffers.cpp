#include <omnetpp.h>
#include <stdlib.h> 
#include <stdio.h> 

class Buffer : public cSimpleModule
{
  private:
	int B, b, M, m, lostPackets, lostTokens, cntTotIn, cntTotOut, i;
	int cntTotIn0, cntTotOut0, b0; // poprzednie stany
	// B - pojemno�� bufora pakiet�w
	// b - aktualna liczba pakiet�w w buforze
	// M - pojemno�� bufora �eton�w
	// m - aktualna liczba �eton�w w buforze
	// lostPackets - liczba zgubionych pakiet�w
	// lostTokens - liczba zgubionych �eton�w
	// cntTotIn - liczba pakiet�w wpadaj�cych do wiadra
	// cntTotOut - liczba pakiet�w, kt�re zosta�y przepuszczone przez wiadro
	simtime_t interval; // interwa� czasu mi�dzy kolejnymi pomiarami intensywno�ci strumieni: wej�ciowego i wyj�ciowego
	simtime_t t0; // poprzedni moment aktualizacji
    cOutVector vectorBP, vectorBT, vectorInStream, vectorOutStream, vectorPIn, vectorPOut;
    cMessage *sendMessageEvent;
	cWeightedStdDev packetBufferStat;

  public:
    Buffer();
    virtual ~Buffer();

  protected:
    virtual void initialize();
    virtual void finish();
    virtual void handleMessage(cMessage *msg);
    virtual void collectContinuous();
};

Define_Module( Buffer );

Buffer::Buffer()
{
	sendMessageEvent = NULL;
}

Buffer::~Buffer()
{
	cancelAndDelete(sendMessageEvent);
}

void Buffer::initialize()
{
	lostPackets = lostTokens = b = cntTotIn = cntTotOut = i = b0 = cntTotIn0 = cntTotOut0 = 0;
	t0 = simTime();
	B = par("packetBufferCapacity");
	M = par("tokenBufferCapacity");
	m = par("initialNoTokens");
	interval = par("measurementInterval");
	
    vectorBP.setName("Liczba pakiet�w w buforze");
    vectorBT.setName("Liczba �eton�w w buforze");
    vectorInStream.setName("Intensywno�� strumienia wej�ciowego");
	vectorOutStream.setName("Intensywno�� strumienia wyj�ciowego");
    vectorPIn.setName("Pakiety na wej�ciu");
    vectorPOut.setName("Pakiety na wyj�ciu");
	packetBufferStat.setName("Liczba pakiet�w w buforze");

	sendMessageEvent = new cMessage("newMeasurement");
	scheduleAt(interval, sendMessageEvent);

	vectorInStream.record(0); 
	vectorOutStream.record(0);
	collectContinuous();
}

void Buffer::handleMessage(cMessage *msg)
{
	// reagowa� na: nadej�cie pakietu, nadej�cie �etonu 
    if (msg->arrivedOn("inP")) // przybycie pakietu
    {
		// je�li bufor pakiet�w jet pe�ny, to pakiet jest tracony
		// je�li bufor pakiet�w nie jest ani pusty, ani pe�ny, to pakiet wchodzi do bufora
		// je�li bufor pakiet�w jest pusty, to:
		//       je�li bufor �eton�w jest pusty, to pakiet wchodzi do bufora
		//       je�li bufor �eton�w nie jest pusty, to pakiet wchodzi do sieci zabieraj�c �eton

		// do wype�nienia
    	collectContinuous();
    	cntTotIn++;
    	vectorPIn.record(cntTotIn);

    	if (b == B)	{
    		delete msg;
    		lostPackets++; //utracono pakiet
    	}
    	else if (b != 0){
    		b++; //dodano do bufora
    		vectorBP.record(b);
    		delete msg;
    	}
    	else {
    		if(m == 0) {
    			b++; //dodanie do bufora
    			vectorBP.record(b);
    			delete msg;
    		}
    		else {
    			m--; //pobranie zetonu
    			vectorBT.record(m);
    			cntTotOut++; //wyjscie pakietu
    			vectorPOut.record(cntTotOut);
    			send(msg, "out");
    		}
    	}
	}
	else if (msg->arrivedOn("inT")) // przybycie �etonu
	{
		// je�li bufor �eton�w jet pe�ny, to �eton jest tracony
		// je�li bufor �eton�w nie jest ani pusty, ani pe�ny, to �eton wchodzi do bufora
		// je�li bufor �eton�w jest pusty, to:
		//       je�li bufor pakiet�w jest pusty, to �eton wchodzi do bufora
		//       je�li bufor pakiet�w nie jest pusty, to pakiet wchodzi do sieci zabieraj�c �eton

		// do wype�nienia
		collectContinuous();
		if (m == M) {
			delete msg;
			lostTokens++; //utracono �eton
		}
		else if (m != 0) {
			m++; //dodano �eton do bufora
			vectorBT.record(m);
			delete msg;
		}
		else {
			if(b == 0) {
				m++;
				vectorBT.record(m);
				delete msg;
			}
			else {
				b--;
				vectorBP.record(b);
				cntTotOut++; //wyjscie pakietu
				vectorPOut.record(cntTotOut);
				send(msg, "out");
			}
		}

	}
	else if (msg->isSelfMessage()) // pomiar intensywno�ci strumieni: wej�ciowego i wyj�ciowego
	{
		i++;
		scheduleAt(simTime()+interval, sendMessageEvent);
		vectorInStream.record((cntTotIn-cntTotIn0)/(interval));
		cntTotIn0 = cntTotIn;
		vectorOutStream.record((cntTotOut-cntTotOut0)/(interval));
		cntTotOut0 = cntTotOut;
	}
}

void Buffer::finish()
{
	vectorBP.record(b);
	vectorBT.record(m);
	collectContinuous();
	packetBufferStat.record();

	FILE *f;
    	f=fopen("packetBufferStat.dat","a");
    	packetBufferStat.saveToFile(f);
    	fclose(f);

	ev << "Packet buffer statistics:" << endl;
	ev << "Mean number of packets in the buffer: " << packetBufferStat.getMean() << endl;
	ev << "Number of lost packets: " << lostPackets << endl;
	ev << "Number of lost tokens: " << lostTokens << endl;
	ev << "Total number of packets in the input stream: " << cntTotIn << endl;
}

void Buffer::collectContinuous() {
  simtime_t t;
  t = simTime();
  packetBufferStat.collect2(b0, (t-t0));
  b0=b;
  t0=t;
}


