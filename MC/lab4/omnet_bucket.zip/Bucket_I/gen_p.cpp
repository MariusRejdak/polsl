#include <omnetpp.h>

class PacketSource : public cSimpleModule
{
  private:
    cMessage *sendMessageEvent;
	simtime_t change;
    simtime_t sendIaTime;
    double ea, eb; // ea - �rednia intensywno�� w <0, change>; eb - �rednia intensywno�� w (change, tmax>

  public:
     PacketSource();
     virtual ~PacketSource();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

Define_Module(PacketSource);

PacketSource::PacketSource()
{
	sendMessageEvent = NULL;
}

PacketSource::~PacketSource()
{
	cancelAndDelete(sendMessageEvent);
}

void PacketSource::initialize()
{
	change = par("changeIntensity");
    ea = par("ea");
    eb = par("eb");
	sendMessageEvent = new cMessage("nextPacket");
	scheduleAt(0.0, sendMessageEvent);
}

void PacketSource::handleMessage(cMessage *msg)
{
	ASSERT(msg==sendMessageEvent);

	cMessage *m = new cMessage("packet");
	send(m, "out");
    sendIaTime = par("sendIaTimeE1"); // liczba losowa ze �redni� 1
    // uwzgl�dnienie zale�no�ci rozk�adu od czasu
    if (simTime() <= change) //
        sendIaTime *= ea;
    else
        sendIaTime *= eb;
    scheduleAt(simTime()+sendIaTime, sendMessageEvent);
}
