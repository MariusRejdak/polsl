package macs;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

/**
 *
 * @author ZAK
 */
public class Hash {

    public static void main(String[] args) throws NoSuchAlgorithmException {
        byte[] buf = Utils.createBuffer(10000000);
        byte[] digest;

        MessageDigest md = MessageDigest.getInstance("SHA-256");

        md.update(buf);
        digest = md.digest();
        
        System.out.println(""+Utils.toHex(digest) );
    }
}
