
package macs;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;



/**
 *
 * @author ZAK
 */
public class CBC {
    public static void main(String[] args) throws Exception
    {
           byte[] key = "0123456789ABCDEF".getBytes();
           SecretKeySpec skeySpec = new SecretKeySpec(key, "AES");

           byte[] buf = Utils.createBuffer(33);

           Cipher cipher = Cipher.getInstance("AES/ECB/NoPadding");
           cipher.init(Cipher.ENCRYPT_MODE, skeySpec);

           byte[] encrypted = cipher.doFinal(buf, 0, 16);
           System.out.println("Encrypted length: " + encrypted.length + " " + Utils.toHex(encrypted));

           encrypted = cipher.doFinal(buf, 16, 16);
           System.out.println("Encrypted length: " + encrypted.length + " " + Utils.toHex(encrypted));

           cipher = Cipher.getInstance("AES/ECB/PKCS5PADDING");
           cipher.init(Cipher.ENCRYPT_MODE, skeySpec);
           byte[] iv = cipher.getIV();

           // cipher.init(Cipher.DECRYPT_MODE, skeySpec, new IvParameterSpec(iv));
           encrypted = cipher.doFinal(buf, 32, 1);

           System.out.println("Encrypted length: " + encrypted.length + " " + Utils.toHex(encrypted));
    }
}
