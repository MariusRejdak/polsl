﻿using PNET_Lab6.Models;
using System;
using System.Collections.Generic;
using Microsoft.AspNet.Identity;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace PNET_Lab6
{
    public partial class _Default : Page
    {
        private UserManager manager = new UserManager();
        private ApplicationDbContext db = new ApplicationDbContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            if(User.Identity.IsAuthenticated)
                sendTopicHolder.Visible = true;

            DataTable dt = new DataTable();
            dt.Columns.Add("title", Type.GetType("System.String"));
            dt.Columns.Add("url", Type.GetType("System.String"));
            dt.Columns.Add("user", Type.GetType("System.String"));
            dt.Columns.Add("date", Type.GetType("System.String"));

            foreach(var t in db.Topics)
            {
                var firstPost = (from p in db.Posts where p.TopicID == t.ID orderby p.Date select p).First();
                var author = manager.FindById(firstPost.AuthorID);

                dt.Rows.Add();
                dt.Rows[dt.Rows.Count - 1]["title"] = t.Title;
                dt.Rows[dt.Rows.Count - 1]["url"] = "~/Topic/?id=" + t.ID;
                dt.Rows[dt.Rows.Count - 1]["user"] = author.UserName;
                dt.Rows[dt.Rows.Count - 1]["date"] = firstPost.Date.ToString();   
            }

            topicGrid.DataSource = dt;
            topicGrid.DataBind();
        }

        protected void topicSend_Click(object sender, EventArgs e)
        {
            var t = new Topic();
            t.Title = topicHeader.Text;
            t = db.Topics.Add(t);
            db.SaveChanges();

            var p = new Post();
            p.AuthorID = User.Identity.GetUserId();
            p.Text = topicText.Text;
            p.Date = DateTime.Now;
            p.TopicID = t.ID;
            db.Posts.Add(p);
            db.SaveChanges();

            topicHeader.Text = "";
            topicText.Text = "";

            Response.Redirect("~/Topic/?id=" + t.ID);
        }
    }
}