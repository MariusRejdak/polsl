﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PNET_Lab6.Startup))]
namespace PNET_Lab6
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
