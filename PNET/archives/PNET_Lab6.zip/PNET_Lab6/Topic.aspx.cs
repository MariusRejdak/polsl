﻿using PNET_Lab6.Models;
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

namespace PNET_Lab6
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        private UserManager manager = new UserManager();
        private ApplicationDbContext db = new ApplicationDbContext();

        protected void Page_Load(object sender, EventArgs e)
        {
            int id;
            try
            {
                id = int.Parse(Request.QueryString["id"]);
            }
            catch
            {
                Response.Redirect("~/Default");
                return;
            }

            if (User.Identity.IsAuthenticated)
                postHolder.Visible = true;

            DataTable dt = new DataTable();
            dt.Columns.Add("user", Type.GetType("System.String"));
            dt.Columns.Add("image", Type.GetType("System.String"));
            dt.Columns.Add("date", Type.GetType("System.String"));
            dt.Columns.Add("text", Type.GetType("System.String"));

            var topic = (from t in db.Topics where t.ID == id orderby t.ID select t).First();
            var posts = from p in db.Posts where p.TopicID == topic.ID orderby p.Date select p;

            topicTitle.InnerText = topic.Title;
            Page.Title = topic.Title;

            foreach (var p in posts)
            {
                var author = manager.FindById(p.AuthorID);

                dt.Rows.Add();
                dt.Rows[dt.Rows.Count - 1]["user"] = author.UserName;
                dt.Rows[dt.Rows.Count - 1]["date"] = p.Date.ToString();
                dt.Rows[dt.Rows.Count - 1]["text"] = p.Text;

                if(author.Image != null && author.Image.Length > 0)
                {
                    dt.Rows[dt.Rows.Count - 1]["image"] = "data:image/jpg;base64," + Convert.ToBase64String(author.Image, 0, author.Image.Length);
                }
                else
                {
                    dt.Rows[dt.Rows.Count - 1]["image"] = "~/brak.png";
                }
            }

            postGrid.DataSource = dt;
            postGrid.DataBind();

            postTopicID.Value = id.ToString();
        }

        protected void postSend_Click(object sender, EventArgs e)
        {
            var p = new Post();
            p.AuthorID = User.Identity.GetUserId();
            p.Text = postText.Text;
            p.Date = DateTime.Now;
            p.TopicID = int.Parse(postTopicID.Value);
            db.Posts.Add(p);
            db.SaveChanges();

            Response.Redirect("~/Topic/?id=" + p.TopicID);
        }
    }
}