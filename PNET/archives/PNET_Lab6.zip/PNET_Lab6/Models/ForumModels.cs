﻿using System;
using System.Data.Entity;

namespace PNET_Lab6.Models
{
    public class Topic
    {
        public int ID { get; set; }
        public string Title { get; set; }
    }

    public class Post
    {
        public int ID { get; set; }
        public int TopicID { get; set; }
        public string AuthorID { get; set; }
        public string Text { get; set; }
        public DateTime Date { get; set; }
    }
}