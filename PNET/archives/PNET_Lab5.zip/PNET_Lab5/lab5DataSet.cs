﻿namespace lab5
{
}
namespace lab5
{
}
namespace lab5 {
    
    
    public partial class lab5DataSet {
    }
}
namespace lab5 {
    
    
    public partial class lab5DataSet {
    }
}

namespace lab5.lab5DataSetTableAdapters {
    
    
    public partial class FirmyTableAdapter {
    }
}
