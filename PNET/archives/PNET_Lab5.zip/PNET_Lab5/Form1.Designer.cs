﻿namespace lab5
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label identyfikatorLabel;
            System.Windows.Forms.Label nazwaLabel;
            System.Windows.Forms.Label stolicaLabel;
            System.Windows.Forms.Label powierzchniaLabel;
            System.Windows.Forms.Label ludnoscLabel;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.wojewodztwaBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.wojewodztwaBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.identyfikatorTextBox = new System.Windows.Forms.TextBox();
            this.nazwaTextBox = new System.Windows.Forms.TextBox();
            this.stolicaTextBox = new System.Windows.Forms.TextBox();
            this.powierzchniaTextBox = new System.Windows.Forms.TextBox();
            this.ludnoscTextBox = new System.Windows.Forms.TextBox();
            this.firmyDataGridView = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.aktywnosc = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.firmyBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.lab5DataSet = new lab5.lab5DataSet();
            this.wojewodztwaBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.wojewodztwaTableAdapter = new lab5.lab5DataSetTableAdapters.WojewodztwaTableAdapter();
            this.firmyTableAdapter = new lab5.lab5DataSetTableAdapters.FirmyTableAdapter();
            this.tableAdapterManager = new lab5.lab5DataSetTableAdapters.TableAdapterManager();
            identyfikatorLabel = new System.Windows.Forms.Label();
            nazwaLabel = new System.Windows.Forms.Label();
            stolicaLabel = new System.Windows.Forms.Label();
            powierzchniaLabel = new System.Windows.Forms.Label();
            ludnoscLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.wojewodztwaBindingNavigator)).BeginInit();
            this.wojewodztwaBindingNavigator.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.firmyDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmyBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lab5DataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wojewodztwaBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // identyfikatorLabel
            // 
            identyfikatorLabel.AutoSize = true;
            identyfikatorLabel.Location = new System.Drawing.Point(12, 37);
            identyfikatorLabel.Name = "identyfikatorLabel";
            identyfikatorLabel.Size = new System.Drawing.Size(68, 13);
            identyfikatorLabel.TabIndex = 1;
            identyfikatorLabel.Text = "Identyfikator:";
            // 
            // nazwaLabel
            // 
            nazwaLabel.AutoSize = true;
            nazwaLabel.Location = new System.Drawing.Point(12, 63);
            nazwaLabel.Name = "nazwaLabel";
            nazwaLabel.Size = new System.Drawing.Size(43, 13);
            nazwaLabel.TabIndex = 3;
            nazwaLabel.Text = "Nazwa:";
            // 
            // stolicaLabel
            // 
            stolicaLabel.AutoSize = true;
            stolicaLabel.Location = new System.Drawing.Point(12, 89);
            stolicaLabel.Name = "stolicaLabel";
            stolicaLabel.Size = new System.Drawing.Size(42, 13);
            stolicaLabel.TabIndex = 5;
            stolicaLabel.Text = "Stolica:";
            // 
            // powierzchniaLabel
            // 
            powierzchniaLabel.AutoSize = true;
            powierzchniaLabel.Location = new System.Drawing.Point(12, 115);
            powierzchniaLabel.Name = "powierzchniaLabel";
            powierzchniaLabel.Size = new System.Drawing.Size(73, 13);
            powierzchniaLabel.TabIndex = 7;
            powierzchniaLabel.Text = "Powierzchnia:";
            // 
            // ludnoscLabel
            // 
            ludnoscLabel.AutoSize = true;
            ludnoscLabel.Location = new System.Drawing.Point(12, 141);
            ludnoscLabel.Name = "ludnoscLabel";
            ludnoscLabel.Size = new System.Drawing.Size(51, 13);
            ludnoscLabel.TabIndex = 9;
            ludnoscLabel.Text = "Ludnosc:";
            // 
            // wojewodztwaBindingNavigator
            // 
            this.wojewodztwaBindingNavigator.AddNewItem = null;
            this.wojewodztwaBindingNavigator.BindingSource = this.wojewodztwaBindingSource;
            this.wojewodztwaBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.wojewodztwaBindingNavigator.DeleteItem = null;
            this.wojewodztwaBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.wojewodztwaBindingNavigatorSaveItem});
            this.wojewodztwaBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.wojewodztwaBindingNavigator.MoveFirstItem = null;
            this.wojewodztwaBindingNavigator.MoveLastItem = null;
            this.wojewodztwaBindingNavigator.MoveNextItem = null;
            this.wojewodztwaBindingNavigator.MovePreviousItem = null;
            this.wojewodztwaBindingNavigator.Name = "wojewodztwaBindingNavigator";
            this.wojewodztwaBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.wojewodztwaBindingNavigator.Size = new System.Drawing.Size(968, 25);
            this.wojewodztwaBindingNavigator.TabIndex = 0;
            this.wojewodztwaBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(36, 22);
            this.bindingNavigatorCountItem.Text = "of {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Total number of items";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Move first";
            this.bindingNavigatorMoveFirstItem.Click += new System.EventHandler(this.bindingNavigatorMoveFirstItem_Click);
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Move previous";
            this.bindingNavigatorMovePreviousItem.Click += new System.EventHandler(this.bindingNavigatorMovePreviousItem_Click);
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Position";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Current position";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveNextItem.Text = "Move next";
            this.bindingNavigatorMoveNextItem.Click += new System.EventHandler(this.bindingNavigatorMoveNextItem_Click);
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveLastItem.Text = "Move last";
            this.bindingNavigatorMoveLastItem.Click += new System.EventHandler(this.bindingNavigatorMoveLastItem_Click);
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Add new";
            this.bindingNavigatorAddNewItem.Click += new System.EventHandler(this.bindingNavigatorAddNewItem_Click);
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorDeleteItem.Text = "Delete";
            this.bindingNavigatorDeleteItem.MouseDown += new System.Windows.Forms.MouseEventHandler(this.bindingNavigatorDeleteItem_MouseDown);
            // 
            // wojewodztwaBindingNavigatorSaveItem
            // 
            this.wojewodztwaBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.wojewodztwaBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("wojewodztwaBindingNavigatorSaveItem.Image")));
            this.wojewodztwaBindingNavigatorSaveItem.Name = "wojewodztwaBindingNavigatorSaveItem";
            this.wojewodztwaBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 22);
            this.wojewodztwaBindingNavigatorSaveItem.Text = "Save Data";
            this.wojewodztwaBindingNavigatorSaveItem.Click += new System.EventHandler(this.wojewodztwaBindingNavigatorSaveItem_Click);
            // 
            // identyfikatorTextBox
            // 
            this.identyfikatorTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.wojewodztwaBindingSource, "identyfikator", true));
            this.identyfikatorTextBox.Location = new System.Drawing.Point(90, 34);
            this.identyfikatorTextBox.Name = "identyfikatorTextBox";
            this.identyfikatorTextBox.Size = new System.Drawing.Size(162, 20);
            this.identyfikatorTextBox.TabIndex = 2;
            this.identyfikatorTextBox.Validating += new System.ComponentModel.CancelEventHandler(this.identyfikatorTextBox_Validating);
            // 
            // nazwaTextBox
            // 
            this.nazwaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.wojewodztwaBindingSource, "nazwa", true));
            this.nazwaTextBox.Location = new System.Drawing.Point(90, 60);
            this.nazwaTextBox.Name = "nazwaTextBox";
            this.nazwaTextBox.Size = new System.Drawing.Size(162, 20);
            this.nazwaTextBox.TabIndex = 4;
            // 
            // stolicaTextBox
            // 
            this.stolicaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.wojewodztwaBindingSource, "stolica", true));
            this.stolicaTextBox.Location = new System.Drawing.Point(90, 86);
            this.stolicaTextBox.Name = "stolicaTextBox";
            this.stolicaTextBox.Size = new System.Drawing.Size(162, 20);
            this.stolicaTextBox.TabIndex = 6;
            // 
            // powierzchniaTextBox
            // 
            this.powierzchniaTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.wojewodztwaBindingSource, "powierzchnia", true));
            this.powierzchniaTextBox.Location = new System.Drawing.Point(90, 112);
            this.powierzchniaTextBox.Name = "powierzchniaTextBox";
            this.powierzchniaTextBox.Size = new System.Drawing.Size(162, 20);
            this.powierzchniaTextBox.TabIndex = 8;
            // 
            // ludnoscTextBox
            // 
            this.ludnoscTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.wojewodztwaBindingSource, "ludnosc", true));
            this.ludnoscTextBox.Location = new System.Drawing.Point(90, 138);
            this.ludnoscTextBox.Name = "ludnoscTextBox";
            this.ludnoscTextBox.Size = new System.Drawing.Size(162, 20);
            this.ludnoscTextBox.TabIndex = 10;
            // 
            // firmyDataGridView
            // 
            this.firmyDataGridView.AutoGenerateColumns = false;
            this.firmyDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.firmyDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn4,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9,
            this.aktywnosc});
            this.firmyDataGridView.DataSource = this.firmyBindingSource;
            this.firmyDataGridView.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.firmyDataGridView.Location = new System.Drawing.Point(0, 165);
            this.firmyDataGridView.Name = "firmyDataGridView";
            this.firmyDataGridView.Size = new System.Drawing.Size(968, 337);
            this.firmyDataGridView.TabIndex = 11;
            this.firmyDataGridView.CellBeginEdit += new System.Windows.Forms.DataGridViewCellCancelEventHandler(this.firmyDataGridView_CellBeginEdit);
            this.firmyDataGridView.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.firmyDataGridView_UserDeletingRow);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(258, 84);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 12;
            this.button1.Text = "Dodaj";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(258, 110);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 13;
            this.button2.Text = "Zapisz";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(258, 136);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 14;
            this.button3.Text = "Usuń";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.MouseDown += new System.Windows.Forms.MouseEventHandler(this.button3_MouseDown);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "identyfikator";
            this.dataGridViewTextBoxColumn1.HeaderText = "identyfikator";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "nazwa";
            this.dataGridViewTextBoxColumn3.HeaderText = "nazwa";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "regon";
            this.dataGridViewTextBoxColumn4.HeaderText = "regon";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "miasto";
            this.dataGridViewTextBoxColumn5.HeaderText = "miasto";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "kodPocztowy";
            this.dataGridViewTextBoxColumn6.HeaderText = "kodPocztowy";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "ulica";
            this.dataGridViewTextBoxColumn7.HeaderText = "ulica";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "numer";
            this.dataGridViewTextBoxColumn8.HeaderText = "numer";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "numerMieszkania";
            this.dataGridViewTextBoxColumn9.HeaderText = "numerMieszkania";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // aktywnosc
            // 
            this.aktywnosc.DataPropertyName = "aktywnosc";
            this.aktywnosc.HeaderText = "aktywnosc";
            this.aktywnosc.Name = "aktywnosc";
            // 
            // firmyBindingSource
            // 
            this.firmyBindingSource.DataMember = "Firmy";
            this.firmyBindingSource.DataSource = this.lab5DataSet;
            // 
            // lab5DataSet
            // 
            this.lab5DataSet.DataSetName = "lab5DataSet";
            this.lab5DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // wojewodztwaBindingSource
            // 
            this.wojewodztwaBindingSource.DataMember = "Wojewodztwa";
            this.wojewodztwaBindingSource.DataSource = this.lab5DataSet;
            this.wojewodztwaBindingSource.Sort = "identyfikator";
            // 
            // wojewodztwaTableAdapter
            // 
            this.wojewodztwaTableAdapter.ClearBeforeFill = true;
            // 
            // firmyTableAdapter
            // 
            this.firmyTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.FirmyTableAdapter = this.firmyTableAdapter;
            this.tableAdapterManager.UpdateOrder = lab5.lab5DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.WojewodztwaTableAdapter = this.wojewodztwaTableAdapter;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(968, 502);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.firmyDataGridView);
            this.Controls.Add(identyfikatorLabel);
            this.Controls.Add(this.identyfikatorTextBox);
            this.Controls.Add(nazwaLabel);
            this.Controls.Add(this.nazwaTextBox);
            this.Controls.Add(stolicaLabel);
            this.Controls.Add(this.stolicaTextBox);
            this.Controls.Add(powierzchniaLabel);
            this.Controls.Add(this.powierzchniaTextBox);
            this.Controls.Add(ludnoscLabel);
            this.Controls.Add(this.ludnoscTextBox);
            this.Controls.Add(this.wojewodztwaBindingNavigator);
            this.Name = "Form1";
            this.Text = "Baza - Marius Rejdak";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.wojewodztwaBindingNavigator)).EndInit();
            this.wojewodztwaBindingNavigator.ResumeLayout(false);
            this.wojewodztwaBindingNavigator.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.firmyDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.firmyBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lab5DataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wojewodztwaBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private lab5DataSet lab5DataSet;
        private System.Windows.Forms.BindingSource wojewodztwaBindingSource;
        private lab5DataSetTableAdapters.WojewodztwaTableAdapter wojewodztwaTableAdapter;
        private System.Windows.Forms.BindingNavigator wojewodztwaBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton wojewodztwaBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox identyfikatorTextBox;
        private System.Windows.Forms.TextBox nazwaTextBox;
        private System.Windows.Forms.TextBox stolicaTextBox;
        private System.Windows.Forms.TextBox powierzchniaTextBox;
        private System.Windows.Forms.TextBox ludnoscTextBox;
        private System.Windows.Forms.BindingSource firmyBindingSource;
        private System.Windows.Forms.DataGridView firmyDataGridView;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewCheckBoxColumn aktywnosc;
        private lab5DataSetTableAdapters.FirmyTableAdapter firmyTableAdapter;
        private lab5DataSetTableAdapters.TableAdapterManager tableAdapterManager;
    }
}

