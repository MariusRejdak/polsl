﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace lab5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private Boolean addNew = false;

        private void wojewodztwaBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.wojewodztwaBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(lab5DataSet);
            lab5DataSet.AcceptChanges();
            this.firmyTableAdapter.FillBy(this.lab5DataSet.Firmy, getCurrentProvince());
            firmyDataGridView.Refresh();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.wojewodztwaTableAdapter.Fill(this.lab5DataSet.Wojewodztwa);
            this.firmyTableAdapter.FillBy(this.lab5DataSet.Firmy, getCurrentProvince());
            wojewodztwaBindingNavigator.DeleteItem = bindingNavigatorDeleteItem;

        }

        private string getCurrentProvince()
        {
            return ((DataRowView)wojewodztwaBindingSource.Current).Row["identyfikator"].ToString();
        }

        private void bindingNavigatorMoveNextItem_Click(object sender, EventArgs e)
        {
            if (!this.Validate())
                return;
            wojewodztwaBindingSource.EndEdit();
            if (lab5DataSet.HasChanges() && this.Validate())
            {
                if (MessageBox.Show("Zapisać zmiany", "Zapisać?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingNavigatorSaveItem.PerformClick();
                }
                else
                {
                    lab5DataSet.RejectChanges();
                }
            }
            wojewodztwaBindingSource.MoveNext();
            firmyTableAdapter.FillBy(lab5DataSet.Firmy, getCurrentProvince());
        }



        private void bindingNavigatorMovePreviousItem_Click(object sender, EventArgs e)
        {
            if (!this.Validate())
                return;
            wojewodztwaBindingSource.EndEdit();
            if (lab5DataSet.HasChanges() && this.Validate())
            {
                if (MessageBox.Show("Zapisać zmiany", "Zapisać?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingNavigatorSaveItem.PerformClick();
                }
                else
                {
                    lab5DataSet.RejectChanges();
                }
            }
            wojewodztwaBindingSource.MovePrevious();
            firmyTableAdapter.FillBy(lab5DataSet.Firmy, getCurrentProvince());
        }

        private void button1_Click(object sender, EventArgs e)
        {
            wojewodztwaBindingSource.AddNew();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            wojewodztwaBindingNavigatorSaveItem.PerformClick();
        }

        private void bindingNavigatorDeleteItem_MouseDown(object sender, MouseEventArgs e)
        {
            string provinceName = ((DataRowView)wojewodztwaBindingSource.Current).Row["nazwa"].ToString();
            firmyBindingSource.Filter = "identyfikatorWojewodztwa = '" + getCurrentProvince() + "'";
            int count = firmyBindingSource.Count;
            firmyBindingSource.Filter = "";
            if (MessageBox.Show(count > 0 ? String.Format("Czy napewno chcesz usunąć województwo {0}\noraz {1} firm?", provinceName, count) : String.Format("Czy napewno chcesz usunąć województwo {0}?", provinceName), "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                wojewodztwaBindingSource.RemoveCurrent();
                wojewodztwaBindingNavigatorSaveItem.PerformClick();
            }
        }

        private void button3_MouseDown(object sender, MouseEventArgs e)
        {
            bindingNavigatorDeleteItem_MouseDown(button3, null);
        }

        private void firmyDataGridView_CellBeginEdit(object sender, DataGridViewCellCancelEventArgs e)
        {
            ((DataRowView)firmyBindingSource.Current).Row["identyfikatorWojewodztwa"] = getCurrentProvince();
        }

        private void firmyDataGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            string companyName = e.Row.Cells[1].Value.ToString();

            if (MessageBox.Show(String.Format("Czy napewno chcesz usunąć firme: \"{0}\"?", companyName), "Warning", MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
            {
                e.Row.Cells["aktywnosc"].Value = false;
                wojewodztwaBindingNavigatorSaveItem.PerformClick();
                e.Cancel = true;
            }
            else
            {
                e.Cancel = true;
            }

        }

        private void identyfikatorTextBox_Validating(object sender, CancelEventArgs e)
        {
            if (identyfikatorTextBox.Text.Length != 3 && addNew)
            {
                if (MessageBox.Show("Identyfikator musi być 3 znakowy.\nAnulować dodawanie?", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingSource.RemoveCurrent();

                    addNew = false;
                }
                else
                {
                    e.Cancel = true;
                }

            }
            else if (identyfikatorTextBox.Text.Length != 3)
            {
                MessageBox.Show("Identyfikator musi być 3 znakowy.", "Warning", MessageBoxButtons.OK);
                e.Cancel = true;
            }
        }

        private void bindingNavigatorMoveLastItem_Click(object sender, EventArgs e)
        {
            if (!this.Validate())
                return;
            wojewodztwaBindingSource.EndEdit();
            if (lab5DataSet.HasChanges() && this.Validate())
            {
                if (MessageBox.Show("Zapisać zmiany", "Zapisać?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingNavigatorSaveItem.PerformClick();
                }
                else
                {
                    lab5DataSet.RejectChanges();
                }
            }
            wojewodztwaBindingSource.MoveLast();
            firmyTableAdapter.FillBy(lab5DataSet.Firmy, getCurrentProvince());
        }

        private void bindingNavigatorMoveFirstItem_Click(object sender, EventArgs e)
        {
            if (!this.Validate())
                return;
            wojewodztwaBindingSource.EndEdit();
            if (lab5DataSet.HasChanges() && this.Validate())
            {
                if (MessageBox.Show("Zapisać zmiany", "Zapisać?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingNavigatorSaveItem.PerformClick();
                }
                else
                {
                    lab5DataSet.RejectChanges();
                }
            }
            wojewodztwaBindingSource.MoveFirst();
            firmyTableAdapter.FillBy(lab5DataSet.Firmy, getCurrentProvince());
        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {
            if (!this.Validate())
                return;
            wojewodztwaBindingSource.EndEdit();
            if (lab5DataSet.HasChanges())
            {
                if (MessageBox.Show("Zapisać zmiany", "Zapisać?", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    wojewodztwaBindingNavigatorSaveItem.PerformClick();
                }
                else
                {
                    lab5DataSet.RejectChanges();
                }
            }
            wojewodztwaBindingSource.AddNew();
            wojewodztwaBindingNavigator.Refresh();
        }
    }
}
