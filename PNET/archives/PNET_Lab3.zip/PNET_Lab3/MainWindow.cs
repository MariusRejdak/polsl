﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace NET
{
    public partial class MainWindow : Form
    {
        private List<TreeNode> documents = new List<TreeNode>();

        public MainWindow()
        {
            InitializeComponent();
        }

        #region delegates service

        /// <summary>
        /// Metoda wywolywana po zmianie sciezki do ktoregos z pliku
        /// </summary>
        public void PathChanged(object sender, EventArgs e)
        {
            foreach (TreeNode node in documents)
                if (node.Tag == sender)
                {
                    node.Text = (node.Tag as TextEdit).GetShortName();
                    node.ToolTipText = (node.Tag as TextEdit).GetFullPath();
                }
        }

        public void DocumentClosing(object sender, EventArgs e)
        {
            foreach (TreeNode node in documents)
                if (node.Tag == sender)
                {
                    treeViewDocuments.Nodes.Remove(node);
                    documents.Remove(node);
                    break;
                }
        }

        #endregion

        #region Printing

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            TextEdit window = null;
            if (this.ActiveMdiChild is TextEdit)
            {
                window = (this.ActiveMdiChild as TextEdit);
            }
            if (window == null) return;

            licznik = window.richTextBox.Print(licznik, window.richTextBox.TextLength, e);

            if (licznik >= window.richTextBox.TextLength)
            {
                e.HasMorePages = false;
            }
            else
            {
                e.HasMorePages = true;
            }
        }

        int licznik = 0;
        private void printDocument1_BeginPrint(object sender, PrintEventArgs e)
        {
            licznik = 0;
        }

        private void PrintDocument_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
                printDocument1.Print();
        }

        private void printPreviewToolStripMenuItem_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.ShowDialog();
        }

        #endregion

        #region I/O / new

        public string GenerateNewName()
        {
            for (int i = 1; ; ++i)
            {
                string name = "document_" + i.ToString();
                int j = 0;
                for (; j < documents.Count; ++j)
                    if ((documents[j].Tag as TextEdit).GetShortName() == name) break;
                if (j == documents.Count) return name;
            }
        }

        public TextEdit newTxtFile(String fileName)
        {
            string newFileName = (fileName == null) ? GenerateNewName() + ".txt" : fileName;

            TextEdit txtWindow = new TextEdit(newFileName);
            txtWindow.MdiParent = this;
            txtWindow.Show();
            txtWindow.PathChanged += PathChanged;
            txtWindow.DocumentClosing += DocumentClosing;

            TreeNode txtTreeNode = new TreeNode(txtWindow.GetShortName(), 3, 3);
            txtTreeNode.Tag = txtWindow;
            treeViewDocuments.Nodes[1].Nodes.Add(txtTreeNode);
            
            txtTreeNode.ToolTipText = txtWindow.GetFullPath();
            txtTreeNode.ContextMenuStrip = txtWindow.GetContextMenu();
            documents.Add(txtTreeNode);
            return txtWindow;
        }

        public RichTextEdit newRtfFile(String fileName)
        {
            string newFileName = (fileName == null) ? GenerateNewName() + ".rtf" : fileName;

            RichTextEdit rtfWindow = new RichTextEdit(newFileName);
            rtfWindow.MdiParent = this;
            rtfWindow.Show();
            rtfWindow.PathChanged += PathChanged;
            rtfWindow.DocumentClosing += DocumentClosing;

            TreeNode rtfTreeNode = new TreeNode(rtfWindow.GetShortName(), 4, 4);
            rtfTreeNode.Tag = rtfWindow;
            treeViewDocuments.Nodes[0].Nodes.Add(rtfTreeNode);
            rtfTreeNode.ContextMenuStrip = rtfWindow.GetContextMenu();

            rtfTreeNode.ToolTipText = rtfWindow.GetFullPath();

            documents.Add(rtfTreeNode);
            return rtfWindow;
        }

        private void newRtf_Click(object sender, EventArgs e)
        {
            newRtfFile(null);
        }

        private void newTxt_Click(object sender, EventArgs e)
        {
            newTxtFile(null);
        }

        private void openToolStripButton_Click(object sender, EventArgs e)
        {
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                TextEdit window;
                if (openFileDialog.FileName.EndsWith("txt"))
                {
                    window = newTxtFile(openFileDialog.FileName);
                    //Dlaczego StreamReader/Writer tu mial byc ??
                    window.LoadContentFromFile(openFileDialog.FileName, RichTextBoxStreamType.PlainText);
                }
                else
                {
                    window = newRtfFile(openFileDialog.FileName);
                    //Dlaczego StreamReader/Writer tu mial byc ??
                    window.LoadContentFromFile(openFileDialog.FileName, RichTextBoxStreamType.RichText);
                }
            }
        }

        private void saveToolStripButton_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild is TextEdit)
            {
                (this.ActiveMdiChild as TextEdit).Save();
            }
        }

        #endregion

        #region treeViewDocument

        private void treeViewDocuments_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Tag != null)
                (e.Node.Tag as Form).BringToFront();
            (sender as Control).Focus();
        }

        #endregion

        #region Text edit

        private void copyToolStripButton_Click(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild as TextEdit) != null)
                (this.ActiveMdiChild as TextEdit).richTextBox.Copy();
        }

        private void pasteToolStripButton_Click(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild as TextEdit) != null)
                (this.ActiveMdiChild as TextEdit).richTextBox.Paste();
        }

        private void cutToolStripButton_Click(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild as TextEdit) != null)
                (this.ActiveMdiChild as TextEdit).richTextBox.Cut();
        }

        private void undoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild as TextEdit) != null)
                (this.ActiveMdiChild as TextEdit).richTextBox.Undo();
        }

        private void redoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if ((this.ActiveMdiChild as TextEdit) != null)
                (this.ActiveMdiChild as TextEdit).richTextBox.Redo();
        }

        #endregion

        #region Toolstrip menu items Clicks

        private void cascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.LayoutMdi(MdiLayout.Cascade);
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void saveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (this.ActiveMdiChild is TextEdit)
            {
                (this.ActiveMdiChild as TextEdit).Save(true);
            }
        }

        #endregion
    }
}

