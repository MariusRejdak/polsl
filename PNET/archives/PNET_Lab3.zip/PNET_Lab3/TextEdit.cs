﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NET
{
    public delegate void FilePathChangedEventHandler(object sender, EventArgs e);
    public delegate void DocumentCloseEventHandler(object sender, EventArgs e);

    public partial class TextEdit : Form
    {
        #region Variables / Events

        public event FilePathChangedEventHandler PathChanged;
        public event DocumentCloseEventHandler DocumentClosing;

        private string fileName;
        public bool isPathSet;
        public bool isTextChanged = false;
        public bool TextChanged 
        {
            get { return isTextChanged; }
            set { isTextChanged = value; SetWindowText(); }
        }

        #endregion

        #region constructors

        public TextEdit(string name)
        {
            InitializeComponent();
            fileName = name;

            this.Text = GetFullPath();
        }

        public TextEdit()
        {
            InitializeComponent();

            SetWindowText();
        }

        #endregion

        #region public Interface

        public void SetPath(string newPath)
        {
            this.fileName = newPath;
            SetWindowText();
            isPathSet = true;

            if (PathChanged != null)
                PathChanged(this, new EventArgs());
        }

        /// <summary>
        /// Funkcja wirtualna TextEdit laduje .txt
        /// </summary>
        /// <param name="filePath"></param>
        public virtual void LoadContentFromFile(string fileName, RichTextBoxStreamType streamType)
        {
            SetPath(fileName);
            richTextBox.LoadFile(GetFullPath(), streamType);
            TextChanged = false;
        }

        public String GetShortName()
        {
            return Path.GetFileNameWithoutExtension(fileName);
        }

        public String GetFullPath()
        {
            return Path.GetFullPath(fileName);
        }

        public void Save(bool saveAs = false)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            bool saveCanceled = false;
            String filter;
            if (this is RichTextEdit)
                filter = "Rtf File|*.rtf|Txt file|*.txt";
            else
                filter = "Txt file|*.txt|Rtf File|*.rtf";

            saveFileDialog.Filter = filter;
            saveFileDialog.InitialDirectory = new FileInfo(GetFullPath()).Directory.ToString();
            saveFileDialog.FileName = GetShortName();

            if (saveAs == true || isPathSet == false)
            {
                if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
                    SetPath(saveFileDialog.FileName);
                else
                    saveCanceled = true;
            }

            if (isPathSet && !saveCanceled)
            {
                RichTextBoxStreamType streamType;
                if (GetFullPath().EndsWith("txt"))
                    streamType = RichTextBoxStreamType.PlainText;
                else
                    streamType = RichTextBoxStreamType.RichText;

                richTextBox.SaveFile(GetFullPath(), streamType);

                TextChanged = false;
                SetWindowText();
            }   
        }

        #endregion

        #region context menu
        public ContextMenuStrip GetContextMenu()
        {
            ContextMenuStrip menu = new ContextMenuStrip();
            menu.Items.Add("&Pokaz", null, menuItemShow);
            menu.Items.Add("&Zapisz", null, menuItemSave);
            menu.Items.Add("Z&amknij", null, menuItemClose);

            return menu;
        }

        private void menuItemShow(object sender, EventArgs e)
        {
            this.BringToFront();
        }

        private void menuItemSave(object sender, EventArgs e)
        {
            this.Save();
        }

        private void menuItemClose(object sender, EventArgs e)
        {
            if (DocumentClosing != null)
                DocumentClosing(this, new EventArgs());
            this.Close();
        }

        #endregion

        #region Private / Protecte methods

        private void SetWindowText()
        {
            this.Text = GetFullPath() + (TextChanged ? "*" : "");
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            if (TextChanged == true)
            {
                DialogResult dialogResult = MessageBox.Show("Save", "Save file" + GetShortName() + "?", MessageBoxButtons.YesNo);
                if (dialogResult == DialogResult.Yes)
                {
                    Save();
                }
            }
            base.OnClosing(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case (Keys.Control | Keys.X):
                    {
                        richTextBox.Cut();
                        return true;
                    }
                case (Keys.Control | Keys.C):
                    {
                        richTextBox.Copy();
                        return true;
                    }
                case (Keys.Control | Keys.V):
                    {
                        richTextBox.Paste();
                        return true;
                    }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }

        private void richTextBox_TextChanged(object sender, EventArgs e)
        {
            TextChanged = true;
        }

        #endregion
    }
}
