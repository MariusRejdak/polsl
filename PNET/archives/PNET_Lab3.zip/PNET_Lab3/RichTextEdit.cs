﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace NET
{
    public partial class RichTextEdit : TextEdit
    {
        public RichTextEdit(string fileName)
            : base(fileName)
        {
            InitializeComponent();
            this.Text = GetFullPath();
        }

        public RichTextEdit()
        {
            InitializeComponent();
        }

        private void toolStripButtonBold_Click(object sender, EventArgs e)
        {
            if (toolStripButtonBold.Checked)
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style | FontStyle.Bold);
            else
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style & ~FontStyle.Bold);
        }

        private void toolStripButtonItalic_Click(object sender, EventArgs e)
        {
            if (toolStripButtonItalic.Checked)
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style | FontStyle.Italic);
            else
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style & ~FontStyle.Italic);
        }

        private void toolStripButtonUnderline_Click(object sender, EventArgs e)
        {
            if (toolStripButtonUnderline.Checked)
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style | FontStyle.Underline);
            else
                richTextBox.SelectionFont = new Font(richTextBox.SelectionFont, richTextBox.SelectionFont.Style & ~FontStyle.Underline);
        }

        private void toolStripButtonFont_Click(object sender, EventArgs e)
        {
            FontDialog fontDialog = new FontDialog
            {
                Font = richTextBox.SelectionFont
            };

            if (fontDialog.ShowDialog(this) == DialogResult.OK)
            {
                richTextBox.SelectionFont = fontDialog.Font;
            }
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case (Keys.Control | Keys.B):
                    {
                        toolStripButtonBold.PerformClick();
                        return true;
                    }
                case (Keys.Control | Keys.U):
                    {
                        toolStripButtonUnderline.PerformClick();
                        return true;
                    }
                case (Keys.Control | Keys.I):
                    {
                        toolStripButtonItalic.PerformClick();
                        return true;
                    }
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
