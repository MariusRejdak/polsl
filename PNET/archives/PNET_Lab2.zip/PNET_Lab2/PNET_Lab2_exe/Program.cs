﻿using PNET_Lab2_lib;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;

namespace PNET_cw1_exe
{
    class Program
    {
        public static void skladowePNET()
        {
            Console.Clear();
            Assembly asem = Assembly.LoadFrom("PNET_cw1_lib.dll");
            Console.WriteLine("Nazwa: " + asem.GetName());

            Type typ = asem.GetTypes()[0];
            Console.WriteLine(typ.BaseType);

            Console.WriteLine("Zmienne (czy prywatna, nazwa):");
            FieldInfo[] zmienne = typ.GetFields();
            for (int i = 0; i < zmienne.Length; i++)
            {
                Console.WriteLine(zmienne[i].IsPrivate + " " + zmienne[i].Name);
            }

            Console.WriteLine("Metody (czy prywatna, nazwa):");
            MethodInfo[] metody = typ.GetMethods();
            for (int i = 0; i < metody.Length; i++)
            {
                Console.WriteLine(metody[i].IsPrivate + " " + metody[i].Name);
            }
            Console.ReadKey();
        }

        public static void about()
        {
            Console.Clear();
            Console.WriteLine("Program Macierz, Platforma .NET");
            Console.WriteLine("Autor: Marius Rejdak");
            Console.ReadKey();
        }

        public static int showMenu()
        {
            int? choice = null;
            while (!choice.HasValue)
            {
                Console.Clear();
                Console.WriteLine("Menu programu Macierz, wybierz akcję:");
                Console.WriteLine("-----------------------------------------");
                Console.WriteLine("1 Operacje na macierzach");
                Console.WriteLine("2 Operacje odczytu/zapisu");
                Console.WriteLine("3 Wyświetlenie składowych podzespołu .NET");
                Console.WriteLine("4 Wyświetlenie informacji o autorze");
                Console.WriteLine("0 Wyjście");

                string s = Console.ReadLine();
                try
                {
                    choice = int.Parse(s);
                }
                catch
                {
                    choice = null;
                }

                if (choice.Value == 0)
                    Environment.Exit(0);
                else if (choice.Value < 0 && choice.Value > 4)
                    choice = null;
            }
            return choice.Value;
        }

        public static void operacjeMacierzowe(ref Macierz a, ref Macierz b, ref Macierz c)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Wybierz operację:");
                Console.WriteLine("-------------------");
                Console.WriteLine("1 Wyświetl wartości");
                Console.WriteLine("2 C = A + B");
                Console.WriteLine("3 C = B + A");
                Console.WriteLine("4 C = A - B");
                Console.WriteLine("5 C = B - A");
                Console.WriteLine("6 C = A * B");
                Console.WriteLine("7 C = B * A");
                Console.WriteLine("8 Suma elementów A");
                Console.WriteLine("9 Suma elementów B");
                Console.WriteLine("0 Wyjście");
                string s = Console.ReadLine();
                int choice = -1;
                try
                {
                    choice = int.Parse(s);
                }
                catch
                {
                    choice = -1;
                }

                if (choice == 0)
                    break;
                else if (choice > 9)
                    continue;

                if (choice > 1 && choice < 8 && (a == null || b == null))
                {
                    Console.WriteLine();
                    if (a == null)
                        Console.WriteLine("Błąd, macierz A nie ma wartości");
                    if (b == null)
                        Console.WriteLine("Błąd, macierz B nie ma wartości");
                    Console.ReadKey();
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        Console.WriteLine();
                        Console.WriteLine("Macierz A:");
                        Console.Write(a != null ? a.ToString() : "null");
                        Console.WriteLine();
                        Console.WriteLine("Macierz B:");
                        Console.Write(b != null ? b.ToString() : "null");
                        Console.WriteLine();
                        Console.WriteLine("Macierz C:");
                        Console.Write(c != null ? c.ToString() : "null");
                        Console.ReadKey();
                        break;
                    case 2:
                        c = a + b;
                        Console.WriteLine();
                        Console.WriteLine("Wykonano c = a + b");
                        Console.ReadKey();
                        break;
                    case 3:
                        c = b + a;
                        Console.WriteLine();
                        Console.WriteLine("Wykonano c = b + a");
                        Console.ReadKey();
                        break;
                    case 4:
                        c = a - b;
                        Console.WriteLine();
                        Console.WriteLine("Wykonano c = a - b");
                        Console.ReadKey();
                        break;
                    case 5:
                        c = b - a;
                        Console.WriteLine();
                        Console.WriteLine("Wykonano c = b - a");
                        Console.ReadKey();
                        break;
                    case 6:
                        Console.WriteLine();
                        try
                        {
                            c = a * b;
                        }
                        catch
                        {
                            Console.WriteLine("Błędne rozmiary macierzy");
                            break;
                        }
                        Console.WriteLine("Wykonano c = a * b");
                        Console.ReadKey();
                        break;
                    case 7:
                        Console.WriteLine();
                        try
                        {
                            c = b * a;
                        }
                        catch
                        {
                            Console.WriteLine("Błędne rozmiary macierzy");
                            break;
                        }
                        Console.WriteLine("Wykonano c = b * a");
                        Console.ReadKey();
                        break;
                    case 8:
                        Console.WriteLine();
                        Console.WriteLine(a != null ? "Suma elementów macierzy A: " + a.sumAll().ToString() : "Błąd, macierz A nie ma wartości");
                        Console.ReadKey();
                        break;
                    case 9:
                        b.sumAll();
                        Console.WriteLine();
                        Console.WriteLine(b != null ? "Suma elementów macierzy B: " + b.sumAll().ToString() : "Błąd, macierz B nie ma wartości");
                        Console.ReadKey();
                        break;
                }

            }
        }

        static void odczyt_zapis(ref Macierz a, ref Macierz b, ref Macierz c)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("Wybierz operację:");
                Console.WriteLine("-------------------");
                Console.WriteLine("1 Wczytaj macierz A");
                Console.WriteLine("2 Wczytaj macierz B");
                Console.WriteLine("3 Zapisz macierz C");
                Console.WriteLine("0 Wyjście");
                string s = Console.ReadLine();
                int choice = -1;
                try
                {
                    choice = int.Parse(s);
                }
                catch
                {
                    choice = -1;
                }

                if (choice == 0)
                    break;
                else if (choice > 3)
                    continue;

                Console.WriteLine();
                try
                {
                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Podaj ścieżkę do pliku:");
                            a = Macierz.fromFile(Console.ReadLine().TrimEnd(new char[] { '\n', '\r' }));
                            Console.WriteLine("Wczytano macierz A:");
                            Console.Write(a.ToString());
                            break;
                        case 2:
                            Console.WriteLine("Podaj ścieżkę do pliku:");
                            b = Macierz.fromFile(Console.ReadLine().TrimEnd(new char[] { '\n', '\r' }));
                            Console.WriteLine("Wczytano macierz B:");
                            Console.Write(b.ToString());
                            break;
                        case 3:
                            Console.WriteLine("Podaj ścieżkę do pliku:");
                            c.saveToFile(Console.ReadLine().TrimEnd(new char[] { '\n', '\r' }));
                            Console.WriteLine("Zapisano macierz C:");
                            Console.Write(c.ToString());
                            break;
                    }
                }
                catch
                {
                    Console.WriteLine("Wystąpił błąd");
                }
                Console.ReadKey();
            }
        }

        static void Main(string[] args)
        {
            Macierz a = null, b = null, c = null;

            while (true)
            {
                int menuOption = showMenu();
                switch (menuOption)
                {
                    case 1:
                        operacjeMacierzowe(ref a, ref b, ref c);
                        break;
                    case 2:
                        odczyt_zapis(ref a, ref b, ref c);
                        break;
                    case 3:
                        skladowePNET();
                        break;
                    case 4:
                        about();
                        break;
                }
            }
        }
    }
}
