﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PNET_cw1_exe
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
