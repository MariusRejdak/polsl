﻿using System;

namespace Komponent
{
    public class OdebranoEventArgs : EventArgs
    {
        public String Tresc { get; private set; }
        public String Nadawca { get; private set; }

        public OdebranoEventArgs(string text, string sender)
        {
            this.Tresc = text;
            this.Nadawca = sender;
        }
    }
}
