﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Komponent
{
    public delegate void OdebranoEventHandler(object sender, OdebranoEventArgs e);

    public partial class Komponent : Component
    {
        private bool disposed   = false;
        private Socket listener = null;
        private Socket client   = null;
        private Thread thread   = null;
        private bool stopThread = false;

        [Category("Action")]
        public event OdebranoEventHandler OdebranoEvent;

        public Komponent()
        {
        }

        public Komponent(IContainer container)
        {
            container.Add(this);
        }

        public void Nasluchuj( int port )
        {
            IPEndPoint localendpoint = new IPEndPoint(IPAddress.Any, port);

            listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listener.Bind(localendpoint);
            listener.Listen(10);

            thread = new Thread(this.Listen);
            thread.Start();
        }

        public void Abort()
        {
            if (thread != null)
            {
                thread.Abort();
                listener.Close();
                listener = null;
                thread = null;
            }
        }

        private void AcceptCallback(object sender, SocketAsyncEventArgs e)
        {
            Socket listenSocket = (Socket)sender;
            client = e.AcceptSocket;

            try
            {
                if (client.Connected)
                {
                    byte[] recvBytes = new byte[100];
                    int bytes;
                    StringBuilder strRetPage = new StringBuilder();

                    do
                    {
                        bytes = client.Receive(recvBytes);
                        strRetPage.Append(Encoding.UTF8.GetString(recvBytes, 0, bytes));

                    } while (client.Connected && client.Available > 0);

                    OnReceiveEvent(this, new OdebranoEventArgs(strRetPage.ToString(), client.RemoteEndPoint.ToString()));
                }
            }
            catch (Exception ex)
            {
                throw;
            }
            finally
            {
                if (client != null)
                    client.Close();
            }

            Listen();
        }

        /// <summary>
        /// Wersja z AsseptAsync aby można bylo wykonac thread.Abort()
        /// </summary>
        public void Listen()
        {
            SocketAsyncEventArgs e = new SocketAsyncEventArgs();
            e.Completed += AcceptCallback;
            if (listener != null && !disposed)
                listener.AcceptAsync(e);
        }

        public bool Wyslij(string adres, int port, string tresc)
        {
            IPHostEntry iphe = Dns.GetHostEntry(adres);
            IPAddress   ip = iphe.AddressList.First(x => x.AddressFamily == AddressFamily.InterNetwork);
            IPEndPoint  ipep = new IPEndPoint(ip, port);
            try
            {
                using (Socket socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp))
                {
                    socket.Connect(ipep);

                    byte[] buffer = Encoding.UTF8.GetBytes(tresc);
                    if ( socket.Send(buffer, buffer.Length, SocketFlags.None) == -1)
                        return false;
                }
            }
            catch (Exception e) 
            {
                return false;
            }
            return true;
        }

        private void OnReceiveEvent(object sender, OdebranoEventArgs args)
        {
            if (OdebranoEvent != null)
            {
                OdebranoEvent(this, args);
            }
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && !this.disposed)
            {
                disposed = true;

                if (thread != null)
                {
                    thread.Abort();
                    thread = null;
                }
                if (listener != null)
                {
                    listener.Close();
                    listener = null;
                }
                if (client != null)
                {
                    client.Close();
                    client = null;
                }
                GC.SuppressFinalize(this);
            }
        }
    }
}
