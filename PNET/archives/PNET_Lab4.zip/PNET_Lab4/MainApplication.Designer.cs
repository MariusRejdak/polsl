﻿namespace Lab4
{
    partial class MainApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.kontrolka1 = new Kontrolka.Kontrolka();
            this.SuspendLayout();
            // 
            // kontrolka1
            // 
            this.kontrolka1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.kontrolka1.Location = new System.Drawing.Point(0, 0);
            this.kontrolka1.Name = "kontrolka1";
            this.kontrolka1.Size = new System.Drawing.Size(599, 415);
            this.kontrolka1.TabIndex = 0;
            // 
            // MainApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(599, 415);
            this.Controls.Add(this.kontrolka1);
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(607, 442);
            this.MinimumSize = new System.Drawing.Size(607, 442);
            this.Name = "MainApplication";
            this.Text = "Komunikator - Marius Rejdak";
            this.ResumeLayout(false);

        }

        #endregion

        private Kontrolka.Kontrolka kontrolka1;

    }
}

