﻿namespace Kontrolka
{
    partial class Kontrolka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.NasluchujButton = new System.Windows.Forms.CheckBox();
            this.textBoxReceivePort = new System.Windows.Forms.TextBox();
            this.buttonSend = new System.Windows.Forms.Button();
            this.textBoxSendPort = new System.Windows.Forms.TextBox();
            this.textBoxSendIP = new System.Windows.Forms.TextBox();
            this.textBoxSend = new System.Windows.Forms.TextBox();
            this.textBoxReceived = new System.Windows.Forms.RichTextBox();
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.statusStrip1 = new System.Windows.Forms.StatusStrip();
            this.Communicator = new Komponent.Komponent(this.components);
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.NasluchujButton);
            this.panel1.Controls.Add(this.textBoxReceivePort);
            this.panel1.Controls.Add(this.buttonSend);
            this.panel1.Controls.Add(this.textBoxSendPort);
            this.panel1.Controls.Add(this.textBoxSendIP);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(596, 77);
            this.panel1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 10;
            this.label1.Text = "Port:";
            // 
            // NasluchujButton
            // 
            this.NasluchujButton.Appearance = System.Windows.Forms.Appearance.Button;
            this.NasluchujButton.Location = new System.Drawing.Point(38, 37);
            this.NasluchujButton.Name = "NasluchujButton";
            this.NasluchujButton.Size = new System.Drawing.Size(75, 23);
            this.NasluchujButton.TabIndex = 9;
            this.NasluchujButton.Text = "&Nasłuchuj";
            this.NasluchujButton.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.NasluchujButton.UseVisualStyleBackColor = true;
            this.NasluchujButton.CheckedChanged += new System.EventHandler(this.NasluchujButton_CheckedChanged);
            // 
            // textBoxReceivePort
            // 
            this.textBoxReceivePort.Location = new System.Drawing.Point(38, 11);
            this.textBoxReceivePort.Name = "textBoxReceivePort";
            this.textBoxReceivePort.Size = new System.Drawing.Size(75, 20);
            this.textBoxReceivePort.TabIndex = 8;
            this.textBoxReceivePort.Text = "1111";
            this.textBoxReceivePort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.validateInt_KeyPress);
            // 
            // buttonSend
            // 
            this.buttonSend.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.buttonSend.Location = new System.Drawing.Point(483, 37);
            this.buttonSend.Name = "buttonSend";
            this.buttonSend.Size = new System.Drawing.Size(75, 23);
            this.buttonSend.TabIndex = 4;
            this.buttonSend.Text = "&Wyślij";
            this.buttonSend.UseVisualStyleBackColor = true;
            this.buttonSend.Click += new System.EventHandler(this.buttonSend_Click);
            // 
            // textBoxSendPort
            // 
            this.textBoxSendPort.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSendPort.Location = new System.Drawing.Point(346, 40);
            this.textBoxSendPort.Name = "textBoxSendPort";
            this.textBoxSendPort.Size = new System.Drawing.Size(131, 20);
            this.textBoxSendPort.TabIndex = 7;
            this.textBoxSendPort.Text = "1111";
            this.textBoxSendPort.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.validateInt_KeyPress);
            // 
            // textBoxSendIP
            // 
            this.textBoxSendIP.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.textBoxSendIP.Location = new System.Drawing.Point(346, 11);
            this.textBoxSendIP.Name = "textBoxSendIP";
            this.textBoxSendIP.Size = new System.Drawing.Size(131, 20);
            this.textBoxSendIP.TabIndex = 6;
            this.textBoxSendIP.Text = "localhost";
            // 
            // textBoxSend
            // 
            this.textBoxSend.Dock = System.Windows.Forms.DockStyle.Fill;
            this.textBoxSend.Location = new System.Drawing.Point(298, 77);
            this.textBoxSend.Multiline = true;
            this.textBoxSend.Name = "textBoxSend";
            this.textBoxSend.ScrollBars = System.Windows.Forms.ScrollBars.Both;
            this.textBoxSend.Size = new System.Drawing.Size(298, 337);
            this.textBoxSend.TabIndex = 16;
            // 
            // textBoxReceived
            // 
            this.textBoxReceived.Dock = System.Windows.Forms.DockStyle.Left;
            this.textBoxReceived.Location = new System.Drawing.Point(0, 77);
            this.textBoxReceived.Name = "textBoxReceived";
            this.textBoxReceived.Size = new System.Drawing.Size(293, 337);
            this.textBoxReceived.TabIndex = 17;
            this.textBoxReceived.Text = "";
            this.textBoxReceived.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBoxReceived_KeyPress);
            // 
            // splitter1
            // 
            this.splitter1.Location = new System.Drawing.Point(293, 77);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(5, 337);
            this.splitter1.TabIndex = 19;
            this.splitter1.TabStop = false;
            // 
            // statusStrip1
            // 
            this.statusStrip1.Location = new System.Drawing.Point(0, 414);
            this.statusStrip1.Name = "statusStrip1";
            this.statusStrip1.Size = new System.Drawing.Size(596, 22);
            this.statusStrip1.TabIndex = 20;
            this.statusStrip1.Text = "statusStrip1";
            // 
            // Communicator
            // 
            this.Communicator.OdebranoEvent += new Komponent.OdebranoEventHandler(this.Communicator_OdebranoEvent);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(290, 14);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(50, 13);
            this.label2.TabIndex = 11;
            this.label2.Text = "Adres IP:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(290, 42);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Port:";
            // 
            // Kontrolka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.textBoxSend);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.textBoxReceived);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.statusStrip1);
            this.Name = "Kontrolka";
            this.Size = new System.Drawing.Size(596, 436);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox textBoxReceivePort;
        private System.Windows.Forms.Button buttonSend;
        private System.Windows.Forms.TextBox textBoxSendPort;
        private System.Windows.Forms.TextBox textBoxSendIP;
        private System.Windows.Forms.TextBox textBoxSend;
        private System.Windows.Forms.RichTextBox textBoxReceived;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.StatusStrip statusStrip1;
        private Komponent.Komponent Communicator;
        private System.Windows.Forms.CheckBox NasluchujButton;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
    }
}
