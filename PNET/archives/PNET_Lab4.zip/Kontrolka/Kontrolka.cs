﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Komponent;

namespace Kontrolka
{
    public partial class Kontrolka: UserControl
    {
        public Kontrolka()
        {
            InitializeComponent();
        }

        private void textBoxReceived_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = true;
        }

        private void buttonSend_Click(object sender, EventArgs e)
        {
            int port = 0;
            if (Int32.TryParse(textBoxSendPort.Text, out port) == true)
            {
                if (Communicator.Wyslij(textBoxSendIP.Text, port, textBoxSend.Text) == true)
                {
                    textBoxSend.Clear();
                }
                else
                {
                    MessageBox.Show("Błąd, nie można wysłać wiadomości, spróbuj ponownie.");
                }
            }
            else
                MessageBox.Show("W polu port proszę podać liczbę");
            textBoxSend.Focus();
        }

        private void Communicator_OdebranoEvent(object sender, OdebranoEventArgs e)
        {
            if (InvokeRequired)
            {
                this.Invoke(new OdebranoEventHandler(Communicator_OdebranoEvent), sender, e);
                return;
            }

            string tekst = string.Format("{0}:{1}", e.Nadawca, Environment.NewLine);
            
            textBoxReceived.AppendText(tekst);
            textBoxReceived.SelectionStart = textBoxReceived.TextLength - (tekst.Length - 1);
            textBoxReceived.SelectionLength = tekst.Length;
            textBoxReceived.SelectionColor = Color.Gray;
            textBoxReceived.DeselectAll();
            textBoxReceived.SelectionStart = textBoxReceived.Text.Length;
            textBoxReceived.ScrollToCaret();
            
            textBoxReceived.AppendText(e.Tresc + Environment.NewLine);
        }

        private void validateInt_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar);
        }

        private void NasluchujButton_CheckedChanged(object sender, EventArgs e)
        {
            if (NasluchujButton.Checked == true)
            {
                textBoxReceivePort.Enabled = false;
                int port = 0;
                if (Int32.TryParse(textBoxReceivePort.Text, out port) == true
                    && port > 0 && port <= 65535)
                {
                    Communicator.Nasluchuj(port);
                }
                else
                {
                    MessageBox.Show("W polu port proszę podać liczbę z zakresu 1 .. 65535 ");
                }
            }
            else
            {
                textBoxReceivePort.Enabled = true;
                Communicator.Abort();
            }
            
        }
    }
}
